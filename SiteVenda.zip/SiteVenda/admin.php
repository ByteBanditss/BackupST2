<?php
// Redirecionamento para a URL desejada
$nova_url = '/admin/admin.php';
header('Location: ' . $nova_url);
exit();
?>
