const hamburger = document.querySelector(".hamburger");
const navlist = document.querySelector(".navlist");

hamburger.addEventListener("click", () => {
	hamburger.classList.toggle('active');
	navlist.classList.toggle('active');
})

document.addEventListener('DOMContentLoaded', function() {
    window.addEventListener('scroll', function() {
        var navbar = document.querySelector('.navbar');

        // Verifica se a rolagem da página ultrapassou a posição do navbar
        if (window.scrollY > navbar.offsetTop) {
            navbar.classList.add('fixed');
        } else {
            navbar.classList.remove('fixed');
        }
    });
});


/* Section Redirect */

document.querySelectorAll('.navbar a').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();

                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

// Exibe ou oculta o botão conforme a rolagem da página
        window.onscroll = function() {
            scrollFunction();
        };

        function scrollFunction() {
            var btn = document.getElementById("backToTopBtn");
            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                btn.style.display = "block";
            } else {
                btn.style.display = "none";
            }
        }

        // Função para rolar suavemente para o topo da página
        function scrollToTop() {
            var currentPosition = document.documentElement.scrollTop || document.body.scrollTop;

            function animateScroll() {
                currentPosition -= 20;
                if (currentPosition > 0) {
                    window.scrollTo(0, currentPosition);
                    requestAnimationFrame(animateScroll);
                } else {
                    window.scrollTo(0, 0);
                }
            }

            animateScroll();
        }



        function sendEmail() {
      const form = document.getElementById('contactForm');
      const formData = new FormData(form);

      fetch('https://formspree.io/f/xqkvgvvr', {
        method: 'POST',
        body: formData,
        headers: {
          'Accept': 'application/json'
        }
      })
      .then(response => response.json())
      .then(data => {
        console.log('Success:', data);
        // Adicione aqui o código para manipular a resposta do servidor
      })
      .catch(error => {
        console.error('Error:', error);
        // Adicione aqui o código para manipular erros
      });
    }