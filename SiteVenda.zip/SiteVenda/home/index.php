<!DOCTYPE html>
    <html lang="pt-br"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/home.css">
    <title>Pagina Inicial</title>
    <link rel="icon" type="image/x-icon" href="https://upload.wikimedia.org/wikipedia/commons/c/c9/Tor_Browser_icon.svg"> 
</head>
<body>
    <div class="matrix-rain"></div>
    <nav class="navbar">
        <h1 class="logo"><a href="#">ByteB</a></h1>
        <ul class="navlist">
            <li class="nav-item"><a href="#home">Inicio</a></li>
            <li class="nav-item"><a href="#about">Sobre</a></li>
            <li class="nav-item"><a href="#skill">Skills</a></li>
            <li class="nav-item"><a href="#contact">Contact</a></li>
        </ul>
        <div class="hamburger">
            <span class="bar"></span>
            <span class="bar"></span>
            <span class="bar"></span>
        </div>
    </nav>

    <div id="home">

<h3 class="main-h3"><div id="home">
    <h1 class="main-h1">Explore o mundo da segurança digital conosco</h1>
    <br>
    <p class="main-p">Aqui, aprenda hacking ético de maneira prática e responsável.</p>
    <button class="btn-int"><a class="btn-int" href="#contact">Iniciar Estudos</a></button>
</div>
</h3> 
</div>

<div id="about">
    <h1 class="sobre-tit">Sobre</h1>
    <br>
    <br>
<p>
Bem-vindo ao ByteB, sua fonte confiável de livros digitais sobre hacking ético e segurança digital. Estamos aqui para proporcionar a você recursos valiosos e práticos que ajudarão a expandir seus conhecimentos e habilidades no mundo da segurança cibernética.</p>
<br>
<br>
<p>
<strong>O Que Oferecemos:</strong>
Oferecemos uma seleção cuidadosa de livros digitais focados em hacking ético, escritos por especialistas no campo. Cada obra foi escolhida para proporcionar uma abordagem acessível e prática para iniciantes e entusiastas.</p>
<br>
<br>

<p>
<strong>Por Que Escolher ByteB:</strong>
- Livros digitais de alta qualidade e relevância.
- Abordagem prática para aprendizado eficaz.
- Foco em hacking ético e segurança responsável.</p>
<br>
<br>
</div>
<div id="skill">
    <h1>Skills</h1>
</div>
<div id="contact">
    <h1>Contato</h1>
    <h2 class="entC">Entre em Contato</h2>

  <form id="contactForm">
    <label for="name">Nome:</label>
    <input type="text" id="name" name="name" required>

    <label for="email">E-mail:</label>
    <input type="email" id="email" name="email" required>

    <label for="message">Mensagem:</label>
    <textarea id="message" name="message" required></textarea>

    <button class="btnev" type="button" onclick="sendEmail()">Enviar</button>
  </form>


  <button class="wimg"><a class="wimg" href="whatsapp://send?phone=+5511958652834" target="_blank"></a>
    <img class="wimg" src="https://cdn-icons-png.flaticon.com/512/3670/3670051.png"></button>
</div>


<button onclick="scrollToTop()" id="backToTopBtn" title="Voltar para o Topo"><div id="backbtn"><img class="imgarrow" src="https://www.seekpng.com/png/full/522-5221323_scroll-arrow-to-up-comments-imagens-de-acento.png"></div></button>

<script type="text/javascript" src="assets/js/home.js"></script>
</body>
</html>