<?php

session_start();

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/ad-page.css">
    <title>Login Admin</title>
    <link rel="icon" type="image/x-icon" href="https://upload.wikimedia.org/wikipedia/commons/c/c9/Tor_Browser_icon.svg"> 
</head>
<body>
    <div class="matrix-rain"></div>
    <div id="login">
        <form class="card" action="login_process.php" method="post">
            <div class="card-header">
                <h2>Login</h2>
            </div>
            <div class="card-content">
                <div class="card-content-area">
                    <label for="usuario" c>Usuário</label>
                    <input type="text" name="usuario" id="usuario" autocomplete="off" required>
                </div>
                <div class="card-content-area">
                    <label for="password" >Senha</label>
                    <input type="password" name="senha" id="senha" autocomplete="off" required>
                </div>
            </div>
            <div class="card-footer">
                <button type="submit" name="submit" value="login" class="submit">Entrar</button>
            </div>
            <p id="textInput"></p>
        </form>
    </div>
</body>
</html>
