<?php
// Configurações do banco de dados
$caminho_banco_dados = '../database/usuarios.db';

// Conexão com o banco de dados (ajuste conforme necessário)
try {
    $conn = new SQLite3($caminho_banco_dados);
} catch (Exception $e) {
    die("Erro de conexão com o banco de dados: " . $e->getMessage());
}

// Verifica se o email foi passado na URL
if (isset($_GET['email'])) {
    $email = $_GET['email'];

    // Lógica para excluir o usuário com o email fornecido
    $stmt = $conn->prepare("DELETE FROM usuarios WHERE email = ?");
    $stmt->bindValue(1, $email, SQLITE3_TEXT);
    $result = $stmt->execute();

    if ($result) {
        // Redireciona de volta para o dashboard após excluir o usuário
        header("Location: add_database.php");
        exit();
    } else {
        echo "Erro ao excluir usuário: " . $conn->lastErrorMsg();
    }

    $stmt->close();
} else {
    // Se o email não foi fornecido na URL, redireciona para o dashboard
    header("Location: add_database.php");
    exit();
}

// Fechar a conexão no final do script
$conn->close();
?>
