<?php
session_start();

// Verifica se o usuário está autenticado
if (!isset($_SESSION['usuario'])) {
    header("Location: admin/admin.php");
    exit();
}

// Configurações do banco de dados
$caminho_banco_dados = '../database/usuarios.db';

// Conexão com o banco de dados (ajuste conforme necessário)
try {
    $conn = new SQLite3($caminho_banco_dados);
} catch (Exception $e) {
    die("Erro de conexão com o banco de dados: " . $e->getMessage());
}

// Lógica para adicionar um novo usuário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT); // Hash da senha para segurança

    // Validar e inserir no banco de dados (usando prepared statements para segurança)
    $stmt = $conn->prepare("INSERT INTO usuarios (email, senha) VALUES (:email, :senha)");
    $stmt->bindValue(':email', $email, SQLITE3_TEXT);
    $stmt->bindValue(':senha', $senha, SQLITE3_TEXT);

    $result = $stmt->execute();

    if ($result) {
        // Redireciona de volta para o dashboard após adicionar o usuário
        header("Location: add_database.php");
        exit();
    } else {
        echo "Erro ao adicionar usuário: " . $conn->lastErrorMsg();
    }

    $stmt->close();
}

// Lista de Usuários Cadastrados
$lista_usuarios = [];

$result = $conn->query("SELECT email FROM usuarios");
while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
    $lista_usuarios[] = $row['email'];
}

// Outras seções do dashboard
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User add</title>
</head>
<style type="text/css">
    /* Reset de estilos */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;500&display=swap');

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Arial', sans-serif;
    background-color: #f5f5f5;
}

.container {
    max-width: 800px;
    margin: 20px auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.nmLg {
    margin-bottom: 3rem;
}

h1, h2 {
    color: #333;
    text-align: center;
}

form {
    margin-top: 20px;
}

label {
    display: block;
    margin-bottom: 5px;
    color: #555;
}

input {
    width: 100%;
    padding: 8px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

button {
    background-color: #4caf50;
    color: #fff;
    padding: 10px 15px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-left: 40% ;
}

button:hover {
    background-color: #45a049;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

table, th, td {
    border: 1px solid #ddd;
}

th, td {
    padding: 10px;
    text-align: left;
}

th {
    background-color: #4caf50;
    color: white;
}

a {
    color: #3498db;
    text-decoration: none;
    margin-left: 10px;
}

a:hover {
    text-decoration: underline;
    color: #1a6090;
}

.logout {
    background-color: red;
    position: fixed;
    margin-top: -65%;
    color: #fff;
    padding: 10px 15px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
 }
</style>
<body>

    <div class="container">
        <h2 class="nmLg">Bem-vindo, <?php echo $_SESSION['usuario']; ?>!</h2>
        <br>
        <br>
        <h2>Adicionar Novo Usuário</h2>

        <form action="add_database.php" method="post">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="senha">Senha:</label>
            <input type="password" id="senha" name="senha" required>

            <button type="submit">Adicionar Usuário</button>
        </form>
        <br>
<br>
        <h2>Usuários Cadastrados</h2>
        <table>
            <tr>
                <th>Email</th>
                <th>Ações</th>
            </tr>
            <?php
            foreach ($lista_usuarios as $usuario) {
                echo "<tr>";
                echo "<td>{$usuario}</td>";
                echo "<td><a href='excluir.php?email={$usuario}'>Excluir</a></td>";
                echo "</tr>";
            }
            ?>
        </table>

        <!-- Outras seções do dashboard -->
       
    </div>

</body>
</html>

<?php
// Fechar a conexão no final do script
$conn->close();
?>
