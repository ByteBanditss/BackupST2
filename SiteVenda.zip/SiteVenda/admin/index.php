<!DOCTYPE html>
<html lang="pt-br">
<head >
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Adhome</title>
</head>
<body>
	<div class="list-card">
	<div class="card1">
		Ir para tela do Banco de dados
		<a href="add_database.php">Entrar</a>
		<br>
			Ir para tela do Gerenciador de arquivos
		<a href="Manager">Entrar</a>
	</div>
	</div>
	 <a class="logout" href="logout.php">Logout</a>
</body>
</html>