<?php
session_start();


// Destroi a sessão
session_destroy();

// Redireciona para a página de login após o logout
header("Location: ../admin/admin.php");
exit();
?>
