<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciador de Arquivos</title>
</head>
<style type="text/css">
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;500&display=swap');


* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
}


h2, h3 {
    color: #333;
    margin-bottom: 1rem;
    text-align: center;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

table, th, td {
    border: 1px solid #ddd;
}

th, td {
    padding: 10px;
    text-align: left;
}

th {
    background-color: #f2f2f2;
}

a {
    text-decoration: none;
    color: #007BFF;
}



.confirmation-popup {
    display: none;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    padding: 20px;
    border: 1px solid #ddd;
    z-index: 999;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.confirmation-popup button {
    margin-right: 10px;
    padding: 8px 16px;
    background-color: #007BFF;
    color: #fff;
    border: none;
    cursor: pointer;
}

.confirmation-popup button:hover {
    background-color: #0056b3;
}


</style>
<body>
    <h2>Gerenciador de Arquivos</h2>

    <?php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    // Função para listar arquivos e pastas
    function listarConteudo($diretorio) {
        $conteudo = scandir($diretorio);
        $conteudo = array_diff($conteudo, array('..', '.'));

        return $conteudo;
    }

    // Diretório base
    $diretorioBase = __DIR__;

    // Diretório de upload
    $diretorioUpload = $diretorioBase . '/upload';

    // Diretório atual
    $diretorioAtual = $diretorioBase;

    // Verificar se um diretório específico foi solicitado
    if (isset($_GET['dir'])) {
        $subdiretorio = $_GET['dir'];
        $diretorioAtual = realpath($diretorioAtual . '/' . $subdiretorio);

        // Certificar-se de que o diretório solicitado é válido
        if (!is_dir($diretorioAtual)) {
            echo "<p></p>";
            $diretorioAtual = $diretorioBase;
        }
    }

    // Lógica para processar o upload
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $uploadDir = $diretorioAtual;

        // Verificar se a pasta de upload existe, se não, criá-la
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        $uploadFile = $uploadDir . '/' . basename($_FILES['file']['name']);

        if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadFile)) {
            echo "<p>Arquivo enviado com sucesso.</p>";
        } else {
            echo "<p>Erro ao enviar o arquivo.</p>";
        }
    }
    ?>

    <h3>Conteúdo do Diretório Atual</h3>
    <table>
        <tr>
            <th>Nome</th>
            <th>Tipo</th>
            <th>Ações</th>
        </tr>

        <?php
        $conteudoDiretorio = listarConteudo($diretorioAtual);

        foreach ($conteudoDiretorio as $item) {
            $caminhoCompleto = $diretorioAtual . '/' . $item;
            echo "<tr>
                    <td><a href='index.php?dir=" . urlencode($item) . "'>$item</a></td>
                    <td>" . (is_dir($caminhoCompleto) ? 'Pasta' : 'Arquivo') . "</td>
                    <td>
                        <a href='delete_handler.php?file=" . urlencode($item) . "'>Excluir</a>
                    </td>
                </tr>";
        }
        ?>
    </table>

</body>
</html>
