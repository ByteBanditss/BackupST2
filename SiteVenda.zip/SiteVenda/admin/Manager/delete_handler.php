<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

function excluirDiretorio($caminho) {
    if (is_dir($caminho)) {
        $conteudo = glob($caminho . '/*');
        
        foreach ($conteudo as $item) {
            if (is_dir($item)) {
                excluirDiretorio($item);
            } else {
                unlink($item);
            }
        }

        rmdir($caminho);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['file'])) {
    // Diretório base
    $diretorioBase = __DIR__;

    // Diretório atual
    $diretorioAtual = $diretorioBase;

    // Verificar se um diretório específico foi solicitado
    if (isset($_GET['dir'])) {
        $subdiretorio = $_GET['dir'];
        $diretorioAtual = realpath($diretorioAtual . '/' . $subdiretorio);

        // Certificar-se de que o diretório solicitado é válido
        if (!is_dir($diretorioAtual)) {
            echo "<p>O diretório especificado não é válido.</p>";
            $diretorioAtual = $diretorioBase;
        }
    }

    $fileToDelete = $diretorioAtual . '/' . urldecode($_GET['file']);

    if (is_file($fileToDelete) || is_link($fileToDelete)) {
        if (unlink($fileToDelete)) {
            echo "<p>Arquivo excluído com sucesso.</p>";
        } else {
            echo "<p>Erro ao tentar excluir o arquivo.</p>";
        }
    } elseif (is_dir($fileToDelete)) {
        excluirDiretorio($fileToDelete);
        echo "<p>Diretório excluído com sucesso.</p>";
    } else {
        echo "<p>O arquivo ou diretório não foi encontrado.</p>";
    }
    
    // Redirecionar para index.php após 2 segundos
    echo '<script>
            setTimeout(function(){
                window.location.href = "index.php?dir=' . urlencode(basename($diretorioAtual)) . '";
            }, 10);
          </script>';
} else {
    echo "<p>Solicitação inválida.</p>";
}
?>
