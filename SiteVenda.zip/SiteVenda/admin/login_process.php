<?php
session_start();

// Caminho para o banco de dados existente
$caminho_banco_dados = '../database/admin.db';

// Conexão com o banco de dados
$banco_dados = new SQLite3($caminho_banco_dados);

// Verifica se a conexão foi bem-sucedida
if (!$banco_dados) {
    die("Conexão falhou");
}

// Recebe os dados do formulário
$usuario = $_POST['usuario'];
$senha = $_POST['senha'];

// Proteção contra SQL injection
$usuario = SQLite3::escapeString($usuario);
$senha = SQLite3::escapeString($senha);

// Consulta ao banco de dados
$query = "SELECT * FROM users WHERE usuario='$usuario' AND senha='$senha'";
$resultado = $banco_dados->query($query);

// Verifica se as credenciais são válidas
if ($resultado->fetchArray()) {
    // Credenciais corretas, redireciona para a página de home
    $_SESSION['usuario'] = $usuario;
    header("Location: index.php");
} else {
    // Credenciais incorretas, redireciona de volta para a página de login
    header("Location: admin.php");
}

// Fecha a conexão com o banco de dados
$banco_dados->close();
?>
