<?php
// Redirecionamento para a URL desejada
$nova_url = 'home/';
header('Location: ' . $nova_url);
exit();
?>
